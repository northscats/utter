import { sql } from "drizzle-orm";
import { pgTable, text, varchar, timestamp, boolean, integer, jsonb, index } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// ============================================================================
// ROLES TABLE
// ============================================================================
export const roles = pgTable("roles", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  name: text("name").notNull().unique().$type<"admin" | "user">(),
  permissions: jsonb("permissions").$type<string[]>().default(sql`'[]'::jsonb`),
  description: text("description"),
});

export const insertRoleSchema = createInsertSchema(roles).omit({ id: true });
export type InsertRole = z.infer<typeof insertRoleSchema>;
export type Role = typeof roles.$inferSelect;

// ============================================================================
// LEGAL ENTITIES TABLE
// ============================================================================
export const LEGAL_ENTITY_TYPES = ['holding', 'subsidiary'] as const;
export type LegalEntityType = typeof LEGAL_ENTITY_TYPES[number];

export const legalEntities = pgTable("legal_entities", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  name: text("name").notNull(),
  shortName: text("short_name"),
  inn: text("inn"),
  type: text("type").notNull().$type<LegalEntityType>(),
  parentId: varchar("parent_id"),
  isActive: boolean("is_active").notNull().default(true),
  createdAt: timestamp("created_at").notNull().defaultNow(),
  updatedAt: timestamp("updated_at").notNull().defaultNow(),
  metadata: jsonb("metadata").$type<Record<string, any>>().default(sql`'{}'::jsonb`),
}, (table) => ({
  parentIdIdx: index("legal_entities_parent_id_idx").on(table.parentId),
  typeIdx: index("legal_entities_type_idx").on(table.type),
}));

export const insertLegalEntitySchema = createInsertSchema(legalEntities).omit({ id: true, createdAt: true, updatedAt: true });
export type InsertLegalEntity = z.infer<typeof insertLegalEntitySchema>;
export type LegalEntity = typeof legalEntities.$inferSelect;

// ============================================================================
// USERS TABLE
// ============================================================================
export const users = pgTable("users", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  username: text("username").notNull().unique(),
  email: text("email"),
  passwordHash: text("password_hash").notNull(),
  roleId: varchar("role_id").notNull().references(() => roles.id),
  gptConsentAccepted: boolean("gpt_consent_accepted").notNull().default(false),
  createdAt: timestamp("created_at").notNull().defaultNow(),
  lastLoginAt: timestamp("last_login_at"),
  isActive: boolean("is_active").notNull().default(true),
  isMemo: boolean("is_memo").notNull().default(false),
  isCss: boolean("is_css").notNull().default(false),
  position: text("position"),
  phone: text("phone"),
  mobilePhone: text("mobile_phone"),
  dismissedAt: timestamp("dismissed_at"),
  avatarUrl: text("avatar_url"),
  legalEntityId: varchar("legal_entity_id").references(() => legalEntities.id, { onDelete: 'set null' }),
  metadata: jsonb("metadata").$type<Record<string, any>>().default(sql`'{}'::jsonb`),
});

export const insertUserSchema = createInsertSchema(users).omit({
  id: true,
  createdAt: true,
  lastLoginAt: true,
}).extend({
  metadata: z.record(z.any()).optional(),
});

export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;

// ============================================================================
// EXPRESS SESSIONS TABLE
// ============================================================================
export const sessions = pgTable("sessions", {
  sid: varchar("sid").primaryKey(),
  sess: jsonb("sess").notNull(),
  expire: timestamp("expire").notNull(),
}, (table) => ({
  expireIdx: index("sessions_expire_idx").on(table.expire),
}));

// ============================================================================
// USER SESSIONS TABLE
// ============================================================================
export const userSessions = pgTable("user_sessions", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").notNull().references(() => users.id, { onDelete: 'cascade' }),
  token: text("token").notNull().unique(),
  refreshToken: text("refresh_token").unique(),
  expiresAt: timestamp("expires_at").notNull(),
  ipAddress: text("ip_address"),
  userAgent: text("user_agent"),
  createdAt: timestamp("created_at").notNull().defaultNow(),
}, (table) => ({
  userIdIdx: index("user_sessions_user_id_idx").on(table.userId),
  expiresAtIdx: index("user_sessions_expires_at_idx").on(table.expiresAt),
}));

export const insertUserSessionSchema = createInsertSchema(userSessions).omit({ id: true, createdAt: true });
export type InsertUserSession = z.infer<typeof insertUserSessionSchema>;
export type UserSession = typeof userSessions.$inferSelect;

// ============================================================================
// SYSTEM CONFIGS TABLE (for Ollama/LLM settings)
// ============================================================================
export const systemConfigs = pgTable("system_configs", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").references(() => users.id, { onDelete: 'cascade' }),
  configKey: text("config_key").notNull(),
  configValue: jsonb("config_value").notNull(),
  isGlobal: boolean("is_global").notNull().default(false),
  createdAt: timestamp("created_at").notNull().defaultNow(),
  updatedAt: timestamp("updated_at").notNull().defaultNow(),
  createdBy: varchar("created_by").references(() => users.id, { onDelete: 'set null' }),
  metadata: jsonb("metadata").$type<Record<string, any>>().default(sql`'{}'::jsonb`),
}, (table) => ({
  userIdIdx: index("system_configs_user_id_idx").on(table.userId),
  configKeyIdx: index("system_configs_config_key_idx").on(table.configKey),
}));

export const insertSystemConfigSchema = createInsertSchema(systemConfigs).omit({ id: true, createdAt: true, updatedAt: true });
export type InsertSystemConfig = z.infer<typeof insertSystemConfigSchema>;
export type SystemConfig = typeof systemConfigs.$inferSelect;

// ============================================================================
// MODULE PERMISSIONS
// ============================================================================
export const MODULE_IDS = {
  MBT: 'mbt',
} as const;

export type ModuleId = typeof MODULE_IDS[keyof typeof MODULE_IDS];

export const userModulePermissions = pgTable("user_module_permissions", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").notNull().references(() => users.id, { onDelete: 'cascade' }),
  moduleId: text("module_id").notNull(),
  hasAccess: boolean("has_access").notNull().default(true),
  createdAt: timestamp("created_at").notNull().defaultNow(),
  updatedAt: timestamp("updated_at").notNull().defaultNow(),
  grantedBy: varchar("granted_by").references(() => users.id, { onDelete: 'set null' }),
  metadata: jsonb("metadata").$type<Record<string, any>>().default(sql`'{}'::jsonb`),
}, (table) => ({
  userIdIdx: index("user_module_permissions_user_id_idx").on(table.userId),
  moduleIdIdx: index("user_module_permissions_module_id_idx").on(table.moduleId),
  userModuleIdx: index("user_module_permissions_user_module_idx").on(table.userId, table.moduleId),
}));

export const insertUserModulePermissionSchema = createInsertSchema(userModulePermissions).omit({ id: true, createdAt: true, updatedAt: true });
export type InsertUserModulePermission = z.infer<typeof insertUserModulePermissionSchema>;
export type UserModulePermission = typeof userModulePermissions.$inferSelect;

// ============================================================================
// MBT (МЕЖБЮДЖЕТНЫЕ ТРАНСФЕРТЫ) PROJECTS
// ============================================================================

export const MBT_FINANCING_METHODS = ['imbt', 'subsidy'] as const;
export const MBT_ACTIVITIES = ['1', '2', '3'] as const;
export const MBT_STATUSES = ['verified', 'sent_to_mef', 'not_agreed'] as const;

export const MBT_FINANCING_LABELS: Record<string, string> = {
  imbt: 'ИМБТ',
  subsidy: 'Субсидия',
};

export const MBT_ACTIVITIES_LABELS: Record<string, string> = {
  '1': 'Мероприятие 1',
  '2': 'Мероприятие 2',
  '3': 'Мероприятие 3',
};

export const MBT_STATUS_LABELS: Record<string, string> = {
  verified: 'Проверено',
  sent_to_mef: 'Направлено в МЭФ',
  not_agreed: 'Не согласовано',
};

export const mbtProjects = pgTable("mbt_projects", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").notNull().references(() => users.id, { onDelete: 'cascade' }),
  name: text("name").notNull(),
  district: text("district"),
  year: integer("year"),
  amountMln: text("amount_mln"),
  financingMethod: text("financing_method").$type<typeof MBT_FINANCING_METHODS[number]>(),
  activities: text("activities").$type<typeof MBT_ACTIVITIES[number]>(),
  status: text("status").$type<typeof MBT_STATUSES[number]>(),
  section: text("section"),
  createdAt: timestamp("created_at").notNull().defaultNow(),
  updatedAt: timestamp("updated_at").notNull().defaultNow(),
}, (table) => ({
  userIdIdx: index("mbt_projects_user_id_idx").on(table.userId),
  createdAtIdx: index("mbt_projects_created_at_idx").on(table.createdAt),
}));

export const insertMbtProjectSchema = createInsertSchema(mbtProjects).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
}).extend({
  district: z.string().optional(),
  year: z.number().optional(),
  amountMln: z.string().optional(),
  financingMethod: z.enum(MBT_FINANCING_METHODS).optional(),
  activities: z.enum(MBT_ACTIVITIES).optional(),
  status: z.enum(MBT_STATUSES).optional(),
  section: z.string().optional(),
});

export type InsertMbtProject = z.infer<typeof insertMbtProjectSchema>;
export type MbtProject = typeof mbtProjects.$inferSelect;

// ============================================================================
// MBT DOCUMENTS TABLE (ZIP archives)
// ============================================================================
export const mbtDocuments = pgTable("mbt_documents", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  projectId: varchar("project_id").notNull().references(() => mbtProjects.id, { onDelete: 'cascade' }),
  userId: varchar("user_id").notNull().references(() => users.id, { onDelete: 'cascade' }),
  filename: text("filename").notNull(),
  originalName: text("original_name").notNull(),
  filePath: text("file_path").notNull(),
  fileSize: text("file_size").notNull(),
  status: text("status").notNull().default('uploaded').$type<"uploaded" | "extracting" | "ready" | "error">(),
  uploadedAt: timestamp("uploaded_at").notNull().defaultNow(),
}, (table) => ({
  projectIdIdx: index("mbt_documents_project_id_idx").on(table.projectId),
}));

export const insertMbtDocumentSchema = createInsertSchema(mbtDocuments).omit({ id: true, uploadedAt: true });
export type InsertMbtDocument = z.infer<typeof insertMbtDocumentSchema>;
export type MbtDocument = typeof mbtDocuments.$inferSelect;

// ============================================================================
// MBT SECTIONS TABLE (project-level section templates)
// ============================================================================
export const mbtSections = pgTable("mbt_sections", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  projectId: varchar("project_id").notNull().references(() => mbtProjects.id, { onDelete: 'cascade' }),
  name: text("name").notNull(),
  order: integer("order").notNull().default(0),
  createdAt: timestamp("created_at").notNull().defaultNow(),
}, (table) => ({
  projectIdIdx: index("mbt_sections_project_id_idx").on(table.projectId),
}));

export const insertMbtSectionSchema = createInsertSchema(mbtSections).omit({ id: true, createdAt: true });
export type InsertMbtSection = z.infer<typeof insertMbtSectionSchema>;
export type MbtSection = typeof mbtSections.$inferSelect;

// ============================================================================
// MBT SECTION RULES TABLE (routing rules per section)
// ============================================================================
export const mbtSectionRules = pgTable("mbt_section_rules", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  sectionId: varchar("section_id").notNull().references(() => mbtSections.id, { onDelete: 'cascade' }),
  type: text("type").notNull().$type<"filename" | "keyword" | "has_artifact">(),
  value: text("value").notNull(),
});

export const insertMbtSectionRuleSchema = createInsertSchema(mbtSectionRules).omit({ id: true });
export type InsertMbtSectionRule = z.infer<typeof insertMbtSectionRuleSchema>;
export type MbtSectionRule = typeof mbtSectionRules.$inferSelect;

// ============================================================================
// MBT MARK BUTTONS TABLE (configurable mark buttons per project/section)
// ============================================================================
export const mbtMarkButtons = pgTable("mbt_mark_buttons", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  projectId: varchar("project_id").notNull().references(() => mbtProjects.id, { onDelete: 'cascade' }),
  sectionId: varchar("section_id"),
  key: text("key").notNull(),
  label: text("label").notNull(),
  order: integer("order").notNull().default(0),
}, (table) => ({
  projectIdIdx: index("mbt_mark_buttons_project_id_idx").on(table.projectId),
}));

export const insertMbtMarkButtonSchema = createInsertSchema(mbtMarkButtons).omit({ id: true });
export type InsertMbtMarkButton = z.infer<typeof insertMbtMarkButtonSchema>;
export type MbtMarkButton = typeof mbtMarkButtons.$inferSelect;

// ============================================================================
// MBT DOCUMENT FILES TABLE (files inside ZIP)
// ============================================================================
export const mbtDocumentFiles = pgTable("mbt_document_files", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  documentId: varchar("document_id").notNull().references(() => mbtDocuments.id, { onDelete: 'cascade' }),
  sectionId: varchar("section_id").references(() => mbtSections.id, { onDelete: 'set null' }),
  filename: text("filename").notNull(),
  fileType: text("file_type").notNull().$type<"pdf" | "docx" | "xlsx" | "other">(),
  filePath: text("file_path").notNull(),
  pdfPath: text("pdf_path"),
  fileSize: text("file_size").notNull(),
  extractionStatus: text("extraction_status").notNull().default('pending').$type<"pending" | "processing" | "completed" | "error">(),
  analysisStatus: text("analysis_status").notNull().default('none').$type<"none" | "processing" | "completed" | "error">(),
  pageCount: integer("page_count").default(0),
  isApproved: boolean("is_approved").notNull().default(false),
  createdAt: timestamp("created_at").notNull().defaultNow(),
}, (table) => ({
  documentIdIdx: index("mbt_doc_files_document_id_idx").on(table.documentId),
}));

export const insertMbtDocumentFileSchema = createInsertSchema(mbtDocumentFiles).omit({ id: true, createdAt: true });
export type InsertMbtDocumentFile = z.infer<typeof insertMbtDocumentFileSchema>;
export type MbtDocumentFile = typeof mbtDocumentFiles.$inferSelect;

// ============================================================================
// MBT DOCUMENT PAGES TABLE (extracted text per page)
// ============================================================================
export const mbtDocumentPages = pgTable("mbt_document_pages", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  fileId: varchar("file_id").notNull().references(() => mbtDocumentFiles.id, { onDelete: 'cascade' }),
  pageNumber: integer("page_number").notNull(),
  textContent: text("text_content").notNull(),
  findingsCache: jsonb("findings_cache"),
  analysisHash: varchar("analysis_hash"),
  createdAt: timestamp("created_at").notNull().defaultNow(),
}, (table) => ({
  fileIdIdx: index("mbt_doc_pages_file_id_idx").on(table.fileId),
  filePageIdx: index("mbt_doc_pages_file_page_idx").on(table.fileId, table.pageNumber),
}));

export const insertMbtDocumentPageSchema = createInsertSchema(mbtDocumentPages).omit({ id: true, createdAt: true });
export type InsertMbtDocumentPage = z.infer<typeof insertMbtDocumentPageSchema>;
export type MbtDocumentPage = typeof mbtDocumentPages.$inferSelect;

// ============================================================================
// MBT ANALYSIS TEMPLATES TABLE (configurable analysis templates)
// ============================================================================

export interface AnalysisParameter {
  key: string;
  label: string;
  color: string;
  enabled: boolean;
  promptText?: string;
}

export const DEFAULT_ANALYSIS_PARAMETERS: AnalysisParameter[] = [
  { key: 'date', label: 'Дата', color: '#22c55e', enabled: true },
  { key: 'signature', label: 'Подпись', color: '#3b82f6', enabled: true },
  { key: 'seal', label: 'Печать', color: '#ef4444', enabled: true },
];

export const mbtAnalysisTemplates = pgTable("mbt_analysis_templates", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  projectId: varchar("project_id").references(() => mbtProjects.id, { onDelete: 'cascade' }),
  name: text("name").notNull(),
  systemPrompt: text("system_prompt").notNull(),
  parameters: jsonb("parameters").$type<AnalysisParameter[]>().notNull().default(sql`'[]'::jsonb`),
  isDefault: boolean("is_default").notNull().default(false),
  roleText: text("role_text"),
  additionalInstructions: text("additional_instructions"),
  createdAt: timestamp("created_at").notNull().defaultNow(),
  updatedAt: timestamp("updated_at").notNull().defaultNow(),
  createdBy: varchar("created_by").references(() => users.id, { onDelete: 'set null' }),
}, (table) => ({
  projectIdIdx: index("mbt_analysis_templates_project_id_idx").on(table.projectId),
}));

export const insertMbtAnalysisTemplateSchema = createInsertSchema(mbtAnalysisTemplates).omit({ id: true, createdAt: true, updatedAt: true });
export type InsertMbtAnalysisTemplate = z.infer<typeof insertMbtAnalysisTemplateSchema>;
export type MbtAnalysisTemplate = typeof mbtAnalysisTemplates.$inferSelect;

// ============================================================================
// MBT DOCUMENT ANALYSES TABLE (AI analysis results)
// ============================================================================
export const MBT_FINDING_TYPES = ['seal', 'signature', 'date'] as const;
export const MBT_FINDING_LABELS: Record<string, string> = {
  seal: 'Печать',
  signature: 'Подпись',
  date: 'Дата',
};
export const MBT_FINDING_COLORS: Record<string, string> = {
  seal: '#ef4444',
  signature: '#3b82f6',
  date: '#22c55e',
};

export const mbtDocumentAnalyses = pgTable("mbt_document_analyses", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  fileId: varchar("file_id").notNull().references(() => mbtDocumentFiles.id, { onDelete: 'cascade' }),
  userId: varchar("user_id").notNull().references(() => users.id, { onDelete: 'cascade' }),
  status: text("status").notNull().default('pending').$type<"pending" | "processing" | "completed" | "error">(),
  model: text("model"),
  templateId: varchar("template_id").references(() => mbtAnalysisTemplates.id, { onDelete: 'set null' }),
  findings: jsonb("findings").$type<Array<{
    type: string;
    textFragment: string;
    page: number;
    description: string;
  }>>().default(sql`'[]'::jsonb`),
  findingsCount: integer("findings_count").default(0),
  errorMessage: text("error_message"),
  progress: integer("progress").default(0),
  progressStage: text("progress_stage"),
  startedAt: timestamp("started_at").notNull().defaultNow(),
  completedAt: timestamp("completed_at"),
}, (table) => ({
  fileIdIdx: index("mbt_doc_analyses_file_id_idx").on(table.fileId),
}));

export const insertMbtDocumentAnalysisSchema = createInsertSchema(mbtDocumentAnalyses).omit({ id: true, startedAt: true, completedAt: true });
export type InsertMbtDocumentAnalysis = z.infer<typeof insertMbtDocumentAnalysisSchema>;
export type MbtDocumentAnalysis = typeof mbtDocumentAnalyses.$inferSelect;

// ============================================================================
// MBT FILE ANNOTATIONS TABLE (marks, approvals, history)
// ============================================================================
export const mbtFileAnnotations = pgTable("mbt_file_annotations", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  fileId: varchar("file_id").notNull().references(() => mbtDocumentFiles.id, { onDelete: 'cascade' }),
  type: text("type").notNull().$type<"mark" | "approve" | "unapprove">(),
  buttonKey: text("button_key"),
  page: integer("page"),
  createdBy: varchar("created_by").notNull().references(() => users.id, { onDelete: 'cascade' }),
  createdAt: timestamp("created_at").notNull().defaultNow(),
  note: text("note"),
}, (table) => ({
  fileIdIdx: index("mbt_file_annotations_file_id_idx").on(table.fileId),
}));

export const insertMbtFileAnnotationSchema = createInsertSchema(mbtFileAnnotations).omit({ id: true, createdAt: true });
export type InsertMbtFileAnnotation = z.infer<typeof insertMbtFileAnnotationSchema>;
export type MbtFileAnnotation = typeof mbtFileAnnotations.$inferSelect;
