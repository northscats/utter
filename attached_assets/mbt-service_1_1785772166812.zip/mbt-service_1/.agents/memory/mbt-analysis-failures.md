---
name: MBT document analysis failures — root causes
description: Why MBT document text-extraction/LLM analysis failed with "Не удалось извлечь текст" and "404 model not found", and the fixes applied.
---

## Symptom 1: "Не удалось извлечь текст из документа" (scanned PDFs)
Analysis was run with `useOcr: false` by default. Scanned PDFs (e.g. produced by scanner software like PaperStream Capture) have no embedded text layer, so basic `pdfplumber` extraction returns 0 pages and the pipeline threw immediately instead of trying OCR.

**Fix:** `analyzeMbtDocument` in `server/services/mbtDocumentAnalysis.ts` now automatically retries extraction with `useOcr: true` when the initial (non-OCR) pass yields zero pages, before surfacing the "cannot extract text" error.

**Why:** OCR (tesseract via subprocess fallback, since `pytesseract`/`opencv` python packages aren't installed but the `tesseract` binary is) works fine and takes ~10-45s per page — acceptable as a fallback, not as the default for every doc (would slow down normal machine-readable PDFs).

## Symptom 2: LLM call returns 404 "model does not exist"
Two separate bugs combined:
1. `callOllama` (used whenever `aiProvider === "ollama"`, which is also used as the generic slot for any custom OpenAI-compatible endpoint like StepFun) built the request URL as `${apiUrl}/api/v1/chat/completions` unconditionally. For providers whose `apiUrl` already includes a version path (e.g. `https://api.stepfun.ai/step_plan/v1`), this produced a double-versioned, wrong URL. Fixed to just append `/chat/completions` (matching the convention already used in `callOpenAIProvider`).
2. The saved "model" config value was literally the provider's display name (e.g. "StepFun") instead of an actual model id. Must be a real model id from the provider's model list (e.g. `step-3.7-flash` for StepFun). This is a per-user config value, not a code bug — always verify the `model` field is a real model id when debugging "model not found" from a custom endpoint.
