import type { Express } from "express";
import { createServer, type Server } from "http";
import passport from "passport";
import multer from "multer";
import { storage } from "./storage";
import { requireAuth, requireModuleAccess } from "./auth";
import { insertMbtProjectSchema } from "@shared/schema";

export async function registerRoutes(app: Express): Promise<Server> {

  // ============================================================================
  // AUTH ROUTES
  // ============================================================================

  app.post("/api/auth/login", (req, res, next) => {
    passport.authenticate("local", (err: any, user: any, info: any) => {
      if (err) return next(err);
      if (!user) {
        return res.status(401).json({ message: info?.message || "Неверный email или пароль" });
      }
      req.logIn(user, (err) => {
        if (err) return next(err);
        return res.json({
          id: user.id,
          email: user.email,
          username: user.username,
          roleId: user.roleId,
          isActive: user.isActive,
        });
      });
    })(req, res, next);
  });

  app.post("/api/auth/logout", (req, res) => {
    req.logout((err) => {
      if (err) return res.status(500).json({ message: "Logout failed" });
      res.json({ message: "Logged out" });
    });
  });

  app.get("/api/auth/me", requireAuth, async (req, res) => {
    const user = req.user as any;
    const role = await storage.getUserRole(user.id);
    res.json({
      id: user.id,
      email: user.email,
      username: user.username,
      roleId: user.roleId,
      role,
      isActive: user.isActive,
    });
  });

  // ============================================================================
  // LLM CONFIG ROUTES
  // ============================================================================

  app.get("/api/ollama/config", requireAuth, async (_req, res) => {
    try {
      const config = await storage.getOllamaConfig();
      res.json(config || {
        apiUrl: process.env.OLLAMA_API_URL || "",
        apiKey: process.env.OLLAMA_API_KEY || "",
        model: process.env.OLLAMA_MODEL || "qwen2.5:7b",
        aiProvider: "ollama",
        openaiApiUrl: "https://api.openai.com/v1",
        openaiModel: "gpt-4o",
        openaiApiKey: process.env.OPENAI_API_KEY || "",
        enableChunking: true,
        maxContextTokens: 28000,
      });
    } catch (error) {
      res.status(500).json({ message: "Failed to get config" });
    }
  });

  app.post("/api/ollama/config", requireAuth, async (req, res) => {
    try {
      await storage.setOllamaConfig(req.body);
      res.json({ message: "Config saved" });
    } catch (error) {
      res.status(500).json({ message: "Failed to save config" });
    }
  });

  // ============================================================================
  // MBT PROJECTS
  // ============================================================================

  app.post("/api/mbt/projects", requireAuth, requireModuleAccess("mbt"), async (req, res) => {
    try {
      const parsed = insertMbtProjectSchema.parse({ ...req.body, userId: req.user!.id });
      const project = await storage.createMbtProject(parsed);
      res.status(201).json(project);
    } catch (error: any) {
      res.status(400).json({ message: error.message || "Failed to create MBT project" });
    }
  });

  app.get("/api/mbt/projects", requireAuth, requireModuleAccess("mbt"), async (_req, res) => {
    try {
      const projects = await storage.getMbtProjects();
      res.json(projects);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch MBT projects" });
    }
  });

  app.get("/api/mbt/projects/:id", requireAuth, requireModuleAccess("mbt"), async (req, res) => {
    try {
      const project = await storage.getMbtProject(req.params.id);
      if (!project) return res.status(404).json({ message: "Project not found" });
      res.json(project);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch MBT project" });
    }
  });

  app.patch("/api/mbt/projects/:id", requireAuth, requireModuleAccess("mbt"), async (req, res) => {
    try {
      const project = await storage.getMbtProject(req.params.id);
      if (!project) return res.status(404).json({ message: "Project not found" });
      const updated = await storage.updateMbtProject(req.params.id, req.body);
      res.json(updated);
    } catch (error: any) {
      res.status(400).json({ message: error.message || "Failed to update MBT project" });
    }
  });

  app.delete("/api/mbt/projects/:id", requireAuth, requireModuleAccess("mbt"), async (req, res) => {
    try {
      const project = await storage.getMbtProject(req.params.id);
      if (!project) return res.status(404).json({ message: "Project not found" });
      await storage.deleteMbtProject(req.params.id);
      res.json({ message: "Project deleted" });
    } catch (error) {
      res.status(500).json({ message: "Failed to delete MBT project" });
    }
  });

  // ============================================================================
  // MBT DOCUMENT ENDPOINTS
  // ============================================================================

  const mbtUpload = multer({
    storage: multer.memoryStorage(),
    limits: { fileSize: 200 * 1024 * 1024 },
  });

  const mbtChunkedSessions = new Map<string, {
    filename: string; fileSize: number; totalChunks: number;
    receivedChunks: Set<number>; tempPath: string; projectId: string; userId: string;
  }>();

  function sanitizeMbtFilename(name: string): string {
    const base = name.replace(/[/\\:*?"<>|]/g, '_').replace(/\.\./g, '_');
    return base.slice(0, 200) || 'document.zip';
  }

  app.post("/api/mbt/projects/:projectId/documents/upload/init", requireAuth, requireModuleAccess("mbt"), async (req, res) => {
    try {
      const { projectId } = req.params;
      const { filename, fileSize, totalChunks } = req.body;
      const project = await storage.getMbtProject(projectId);
      if (!project) return res.status(404).json({ message: "Project not found" });

      const safeName = sanitizeMbtFilename(filename);
      const numSize = Number(fileSize);
      const numChunks = Number(totalChunks);
      if (!numSize || numSize <= 0 || numSize > 500 * 1024 * 1024)
        return res.status(400).json({ message: "Invalid file size" });
      if (!numChunks || numChunks <= 0 || numChunks > 200)
        return res.status(400).json({ message: "Invalid chunk count" });

      const uploadId = `mbt_${Date.now()}_${Math.random().toString(36).slice(2, 8)}`;
      const fs = await import('fs');
      const path = await import('path');
      const dir = path.join(process.cwd(), 'uploads', 'mbt', projectId);
      fs.mkdirSync(dir, { recursive: true });
      const tempPath = path.join('/tmp', `mbt_chunk_${uploadId}`);
      fs.writeFileSync(tempPath, Buffer.alloc(0));

      mbtChunkedSessions.set(uploadId, {
        filename: safeName, fileSize: numSize, totalChunks: numChunks,
        receivedChunks: new Set(),
        tempPath, projectId, userId: req.user!.id,
      });

      res.json({ uploadId });
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  app.post("/api/mbt/projects/:projectId/documents/upload/chunk", requireAuth, requireModuleAccess("mbt"), mbtUpload.single('chunk'), async (req, res) => {
    try {
      const { uploadId, chunkIndex } = req.body;
      const session = mbtChunkedSessions.get(uploadId);
      if (!session) return res.status(400).json({ message: "Invalid upload session" });
      if (session.userId !== req.user!.id || session.projectId !== req.params.projectId)
        return res.status(403).json({ message: "Session mismatch" });
      if (!req.file) return res.status(400).json({ message: "No chunk data" });

      const fs = await import('fs');
      const CHUNK_SIZE = 5 * 1024 * 1024;
      const idx = parseInt(chunkIndex);
      if (isNaN(idx) || idx < 0 || idx >= session.totalChunks)
        return res.status(400).json({ message: "Invalid chunk index" });

      const fd = fs.openSync(session.tempPath, 'r+');
      fs.writeSync(fd, req.file.buffer, 0, req.file.buffer.length, idx * CHUNK_SIZE);
      fs.closeSync(fd);

      session.receivedChunks.add(idx);
      res.json({ received: session.receivedChunks.size, total: session.totalChunks });
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  app.post("/api/mbt/projects/:projectId/documents/upload/finalize", requireAuth, requireModuleAccess("mbt"), async (req, res) => {
    try {
      const { uploadId } = req.body;
      const session = mbtChunkedSessions.get(uploadId);
      if (!session) return res.status(400).json({ message: "Invalid upload session" });
      if (session.userId !== req.user!.id || session.projectId !== req.params.projectId)
        return res.status(403).json({ message: "Session mismatch" });
      if (session.receivedChunks.size !== session.totalChunks)
        return res.status(400).json({ message: `Missing chunks: ${session.receivedChunks.size}/${session.totalChunks}` });

      const fs = await import('fs');
      const path = await import('path');

      const stat = fs.statSync(session.tempPath);
      if (stat.size > session.fileSize) {
        fs.truncateSync(session.tempPath, session.fileSize);
      }

      const dir = path.join(process.cwd(), 'uploads', 'mbt', session.projectId);
      fs.mkdirSync(dir, { recursive: true });
      const destFilename = `${Date.now()}_${sanitizeMbtFilename(session.filename)}`;
      const destPath = path.join(dir, destFilename);
      fs.copyFileSync(session.tempPath, destPath);
      fs.unlinkSync(session.tempPath);

      const doc = await storage.createMbtDocument({
        projectId: session.projectId,
        userId: session.userId,
        filename: destFilename,
        originalName: session.filename,
        filePath: destPath,
        fileSize: String(session.fileSize),
        status: 'extracting',
      });

      mbtChunkedSessions.delete(uploadId);

      const { extractZipAndCreateFiles } = await import('./services/mbtDocumentAnalysis');
      extractZipAndCreateFiles(doc.id, destPath, dir).catch(err => {
        console.error("MBT ZIP extraction error:", err);
      });

      res.json(doc);
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  app.post("/api/mbt/projects/:projectId/documents/upload", requireAuth, requireModuleAccess("mbt"), mbtUpload.single('file'), async (req, res) => {
    try {
      const { projectId } = req.params;
      if (!req.file) return res.status(400).json({ message: "No file uploaded" });

      const project = await storage.getMbtProject(projectId);
      if (!project) return res.status(404).json({ message: "Project not found" });

      const fs = await import('fs');
      const path = await import('path');
      const dir = path.join(process.cwd(), 'uploads', 'mbt', projectId);
      fs.mkdirSync(dir, { recursive: true });

      const safeOrigName = sanitizeMbtFilename(req.file.originalname);
      const destFilename = `${Date.now()}_${safeOrigName}`;
      const destPath = path.join(dir, destFilename);
      fs.writeFileSync(destPath, req.file.buffer);

      const doc = await storage.createMbtDocument({
        projectId,
        userId: req.user!.id,
        filename: destFilename,
        originalName: safeOrigName,
        filePath: destPath,
        fileSize: String(req.file.size),
        status: 'extracting',
      });

      const { extractZipAndCreateFiles } = await import('./services/mbtDocumentAnalysis');
      extractZipAndCreateFiles(doc.id, destPath, dir).catch(err => {
        console.error("MBT ZIP extraction error:", err);
      });

      res.json(doc);
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  app.get("/api/mbt/projects/:projectId/documents", requireAuth, requireModuleAccess("mbt"), async (req, res) => {
    try {
      const docs = await storage.getMbtDocuments(req.params.projectId);
      res.json(docs);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch documents" });
    }
  });

  app.delete("/api/mbt/documents/:id", requireAuth, requireModuleAccess("mbt"), async (req, res) => {
    try {
      const doc = await storage.getMbtDocument(req.params.id);
      if (!doc) return res.status(404).json({ message: "Document not found" });
      const fs = await import('fs');
      const files = await storage.getMbtDocumentFiles(doc.id);
      for (const f of files) {
        try { if (f.filePath) fs.unlinkSync(f.filePath); } catch {}
        try { if (f.pdfPath) fs.unlinkSync(f.pdfPath); } catch {}
      }
      try { fs.unlinkSync(doc.filePath); } catch {}
      await storage.deleteMbtDocument(req.params.id);
      res.json({ message: "Document deleted" });
    } catch (error) {
      res.status(500).json({ message: "Failed to delete document" });
    }
  });

  app.get("/api/mbt/documents/:documentId/files", requireAuth, requireModuleAccess("mbt"), async (req, res) => {
    try {
      const files = await storage.getMbtDocumentFiles(req.params.documentId);
      res.json(files);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch files" });
    }
  });

  app.get("/api/mbt/files/:fileId/serve", requireAuth, requireModuleAccess("mbt"), async (req, res) => {
    try {
      const file = await storage.getMbtDocumentFile(req.params.fileId);
      if (!file) return res.status(404).json({ message: "File not found" });
      const fs = await import('fs');
      const servePath = file.pdfPath || file.filePath;
      if (!fs.existsSync(servePath)) {
        return res.status(404).json({ message: "File not found on disk" });
      }
      res.setHeader('Content-Type', 'application/pdf');
      res.setHeader('Content-Disposition', `inline; filename="${encodeURIComponent(file.filename)}"`);
      const stream = fs.createReadStream(servePath);
      stream.pipe(res);
    } catch (error) {
      res.status(500).json({ message: "Failed to serve file" });
    }
  });

  app.post("/api/mbt/files/:fileId/analyze", requireAuth, requireModuleAccess("mbt"), async (req, res) => {
    try {
      const file = await storage.getMbtDocumentFile(req.params.fileId);
      if (!file) return res.status(404).json({ message: "File not found" });

      let templateConfig: { systemPrompt?: string; parameters?: any[]; templateId?: string } = {};
      if (req.body.templateId) {
        const tmpl = await storage.getAnalysisTemplate(req.body.templateId);
        if (tmpl) {
          templateConfig = { systemPrompt: tmpl.systemPrompt, parameters: tmpl.parameters, templateId: tmpl.id };
        }
      } else if (req.body.customParameters) {
        templateConfig = { parameters: req.body.customParameters, systemPrompt: req.body.systemPrompt };
      }

      const options = {
        findDates: req.body.findDates !== false,
        findSignatures: req.body.findSignatures !== false,
        findSeals: req.body.findSeals !== false,
        useOcr: !!req.body.useOcr,
        ...templateConfig,
      };
      const { analyzeMbtDocument } = await import('./services/mbtDocumentAnalysis');
      analyzeMbtDocument(req.params.fileId, req.user!.id, options).catch(err => {
        console.error("MBT analysis error:", err);
      });
      res.json({ message: "Analysis started" });
    } catch (error) {
      res.status(500).json({ message: "Failed to start analysis" });
    }
  });

  app.get("/api/mbt/files/:fileId/analysis", requireAuth, requireModuleAccess("mbt"), async (req, res) => {
    try {
      const analysis = await storage.getLatestMbtAnalysis(req.params.fileId);
      res.json(analysis || null);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch analysis" });
    }
  });

  app.post("/api/mbt/batch-analyze", requireAuth, requireModuleAccess("mbt"), async (req, res) => {
    try {
      const { fileIds, skipAnalyzed = false, ...settingsRaw } = req.body;
      if (!Array.isArray(fileIds) || fileIds.length === 0)
        return res.status(400).json({ message: "fileIds is required and must be a non-empty array" });

      let templateConfig: { systemPrompt?: string; parameters?: any[]; templateId?: string } = {};
      if (settingsRaw.templateId) {
        const tmpl = await storage.getAnalysisTemplate(settingsRaw.templateId);
        if (tmpl) {
          templateConfig = { systemPrompt: tmpl.systemPrompt, parameters: tmpl.parameters, templateId: tmpl.id };
        }
      } else if (settingsRaw.customParameters) {
        templateConfig = { parameters: settingsRaw.customParameters, systemPrompt: settingsRaw.systemPrompt };
      }

      const options = {
        findDates: settingsRaw.findDates !== false,
        findSignatures: settingsRaw.findSignatures !== false,
        findSeals: settingsRaw.findSeals !== false,
        useOcr: !!settingsRaw.useOcr,
        ...templateConfig,
      };
      const { analyzeMbtDocument } = await import('./services/mbtDocumentAnalysis');
      let queued = 0;
      for (const fileId of fileIds) {
        const file = await storage.getMbtDocumentFile(fileId);
        if (!file) continue;
        if (skipAnalyzed && file.analysisStatus === 'completed') continue;
        analyzeMbtDocument(fileId, req.user!.id, options).catch(err => {
          console.error(`MBT batch analysis error for ${fileId}:`, err);
        });
        queued++;
      }
      res.json({ message: "Batch analysis started", queued });
    } catch (error) {
      res.status(500).json({ message: "Failed to start batch analysis" });
    }
  });

  // ── MBT Analysis Templates ───────────────────────────────────────────────────
  app.get("/api/mbt/analysis-templates", requireAuth, requireModuleAccess("mbt"), async (req, res) => {
    try {
      const projectId = req.query.projectId as string | undefined;
      const templates = await storage.getAnalysisTemplates(projectId);
      res.json(templates);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch analysis templates" });
    }
  });

  app.post("/api/mbt/analysis-templates", requireAuth, requireModuleAccess("mbt"), async (req, res) => {
    try {
      const { name, systemPrompt, parameters, projectId, isDefault } = req.body;
      if (!name || !systemPrompt) return res.status(400).json({ message: "name and systemPrompt are required" });
      const template = await storage.createAnalysisTemplate({
        name,
        systemPrompt,
        parameters: parameters || [],
        projectId: projectId || null,
        isDefault: !!isDefault,
        createdBy: req.user!.id,
      });
      res.status(201).json(template);
    } catch (error) {
      res.status(500).json({ message: "Failed to create analysis template" });
    }
  });

  app.put("/api/mbt/analysis-templates/:id", requireAuth, requireModuleAccess("mbt"), async (req, res) => {
    try {
      const existing = await storage.getAnalysisTemplate(req.params.id);
      if (!existing) return res.status(404).json({ message: "Template not found" });
      const { name, systemPrompt, parameters, isDefault } = req.body;
      const updated = await storage.updateAnalysisTemplate(req.params.id, {
        ...(name !== undefined && { name }),
        ...(systemPrompt !== undefined && { systemPrompt }),
        ...(parameters !== undefined && { parameters }),
        ...(isDefault !== undefined && { isDefault }),
      });
      res.json(updated);
    } catch (error) {
      res.status(500).json({ message: "Failed to update analysis template" });
    }
  });

  app.delete("/api/mbt/analysis-templates/:id", requireAuth, requireModuleAccess("mbt"), async (req, res) => {
    try {
      const existing = await storage.getAnalysisTemplate(req.params.id);
      if (!existing) return res.status(404).json({ message: "Template not found" });
      await storage.deleteAnalysisTemplate(req.params.id);
      res.json({ message: "Template deleted" });
    } catch (error) {
      res.status(500).json({ message: "Failed to delete analysis template" });
    }
  });

  // ── MBT Sections ────────────────────────────────────────────────────────────
  app.get("/api/mbt/projects/:projectId/sections", requireAuth, requireModuleAccess("mbt"), async (req, res) => {
    try {
      res.json(await storage.getMbtSections(req.params.projectId));
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch sections" });
    }
  });

  app.post("/api/mbt/projects/:projectId/sections", requireAuth, requireModuleAccess("mbt"), async (req, res) => {
    try {
      const { name, order } = req.body;
      res.json(await storage.createMbtSection({ projectId: req.params.projectId, name, order: order ?? 0 }));
    } catch (error) {
      res.status(500).json({ message: "Failed to create section" });
    }
  });

  app.patch("/api/mbt/sections/:id", requireAuth, requireModuleAccess("mbt"), async (req, res) => {
    try {
      res.json(await storage.updateMbtSection(req.params.id, req.body));
    } catch (error) {
      res.status(500).json({ message: "Failed to update section" });
    }
  });

  app.delete("/api/mbt/sections/:id", requireAuth, requireModuleAccess("mbt"), async (req, res) => {
    try {
      await storage.deleteMbtSection(req.params.id);
      res.json({ ok: true });
    } catch (error) {
      res.status(500).json({ message: "Failed to delete section" });
    }
  });

  app.post("/api/mbt/sections/:id/rules", requireAuth, requireModuleAccess("mbt"), async (req, res) => {
    try {
      const { type, value } = req.body;
      res.json(await storage.createMbtSectionRule({ sectionId: req.params.id, type, value }));
    } catch (error) {
      res.status(500).json({ message: "Failed to create rule" });
    }
  });

  app.patch("/api/mbt/section-rules/:id", requireAuth, requireModuleAccess("mbt"), async (req, res) => {
    try {
      res.json(await storage.updateMbtSectionRule(req.params.id, req.body.value));
    } catch (error) {
      res.status(500).json({ message: "Failed to update rule" });
    }
  });

  app.delete("/api/mbt/section-rules/:id", requireAuth, requireModuleAccess("mbt"), async (req, res) => {
    try {
      await storage.deleteMbtSectionRule(req.params.id);
      res.json({ ok: true });
    } catch (error) {
      res.status(500).json({ message: "Failed to delete rule" });
    }
  });

  app.patch("/api/mbt/files/:fileId/section", requireAuth, requireModuleAccess("mbt"), async (req, res) => {
    try {
      const { sectionId } = req.body;
      res.json(await storage.updateMbtFileSection(req.params.fileId, sectionId ?? null));
    } catch (error) {
      res.status(500).json({ message: "Failed to update file section" });
    }
  });

  app.post("/api/mbt/documents/:id/route", requireAuth, requireModuleAccess("mbt"), async (req, res) => {
    try {
      const doc = await storage.getMbtDocument(req.params.id);
      if (!doc) return res.status(404).json({ message: "Document not found" });
      const count = await storage.routeMbtDocumentFiles(doc.id, doc.projectId);
      res.json({ routed: count });
    } catch (error) {
      res.status(500).json({ message: "Failed to route files" });
    }
  });

  // ── MBT Mark Buttons ────────────────────────────────────────────────────────
  app.get("/api/mbt/projects/:id/mark-buttons", requireAuth, requireModuleAccess("mbt"), async (req, res) => {
    try {
      const { sectionId } = req.query;
      res.json(await storage.getMbtMarkButtons(req.params.id, sectionId as string | undefined));
    } catch (error) {
      res.status(500).json({ message: "Failed to get mark buttons" });
    }
  });

  app.post("/api/mbt/projects/:id/mark-buttons", requireAuth, requireModuleAccess("mbt"), async (req, res) => {
    try {
      const { label, key, sectionId, order } = req.body;
      res.json(await storage.createMbtMarkButton({
        projectId: req.params.id,
        key: key || label.toLowerCase().replace(/\s+/g, '_'),
        label,
        sectionId: sectionId || null,
        order: order ?? 0,
      }));
    } catch (error) {
      res.status(500).json({ message: "Failed to create mark button" });
    }
  });

  app.patch("/api/mbt/mark-buttons/:id", requireAuth, requireModuleAccess("mbt"), async (req, res) => {
    try {
      const { label, order } = req.body;
      res.json(await storage.updateMbtMarkButton(req.params.id, { label, order }));
    } catch (error) {
      res.status(500).json({ message: "Failed to update mark button" });
    }
  });

  app.delete("/api/mbt/mark-buttons/:id", requireAuth, requireModuleAccess("mbt"), async (req, res) => {
    try {
      await storage.deleteMbtMarkButton(req.params.id);
      res.json({ ok: true });
    } catch (error) {
      res.status(500).json({ message: "Failed to delete mark button" });
    }
  });

  // ── MBT File Annotations ────────────────────────────────────────────────────
  app.get("/api/mbt/files/:fileId/annotations", requireAuth, requireModuleAccess("mbt"), async (req, res) => {
    try {
      res.json(await storage.getMbtFileAnnotations(req.params.fileId));
    } catch (error) {
      res.status(500).json({ message: "Failed to get annotations" });
    }
  });

  app.post("/api/mbt/files/:fileId/marks/toggle", requireAuth, requireModuleAccess("mbt"), async (req, res) => {
    try {
      const { buttonKey, page } = req.body;
      const userId = (req as any).user?.id;
      const pageNum = parseInt(page, 10) || 1;
      res.json(await storage.toggleMbtFileMark(req.params.fileId, buttonKey, userId, pageNum));
    } catch (error) {
      res.status(500).json({ message: "Failed to toggle mark" });
    }
  });

  app.post("/api/mbt/files/:fileId/approve", requireAuth, requireModuleAccess("mbt"), async (req, res) => {
    try {
      const { approved } = req.body;
      const userId = (req as any).user?.id;
      res.json(await storage.approveMbtFile(req.params.fileId, !!approved, userId));
    } catch (error) {
      res.status(500).json({ message: "Failed to approve file" });
    }
  });

  app.delete("/api/mbt/annotations/:id", requireAuth, requireModuleAccess("mbt"), async (req, res) => {
    try {
      await storage.deleteMbtFileAnnotation(req.params.id);
      res.json({ ok: true });
    } catch (error) {
      res.status(500).json({ message: "Failed to delete annotation" });
    }
  });

  // ── MBT Report ──────────────────────────────────────────────────────────────
  app.get("/api/mbt/report", requireAuth, requireModuleAccess("mbt"), async (req, res) => {
    try {
      const { projectId, documentId, sectionId, fileId, format } = req.query as Record<string, string>;
      if (!projectId) return res.status(400).json({ message: "projectId required" });

      const data = await storage.getMbtReportData({ projectId, documentId, sectionId, fileId });

      if (format === 'xlsx') {
        const ExcelJS = (await import('exceljs')).default;
        const wb = new ExcelJS.Workbook();
        const ws = wb.addWorksheet('Отчёт МБТ');

        ws.columns = [
          { header: '№', key: 'num', width: 5 },
          { header: 'Файл', key: 'filename', width: 35 },
          { header: 'Раздел', key: 'section', width: 22 },
          { header: 'Согласован', key: 'approved', width: 13 },
          { header: 'Печатей', key: 'seals', width: 10 },
          { header: 'Подписей', key: 'signatures', width: 11 },
          { header: 'Дат', key: 'dates', width: 8 },
          { header: 'Отметки', key: 'marks', width: 40 },
          { header: 'Статус анализа', key: 'analysis', width: 16 },
        ];

        const headerRow = ws.getRow(1);
        headerRow.font = { bold: true, size: 11 };
        headerRow.fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: 'FFE2E8F0' } };
        headerRow.alignment = { vertical: 'middle', wrapText: true };
        headerRow.height = 20;

        const ANALYSIS_LABELS: Record<string, string> = {
          completed: 'Завершён', processing: 'Обрабатывается',
          error: 'Ошибка', none: 'Не запускался', pending: 'Ожидает',
        };

        let rowNum = 2;
        let lastSectionId: string | null | undefined = undefined;
        let sectionSealSum = 0, sectionSigSum = 0, sectionDateSum = 0;

        const flushSectionTotal = (secName: string | null) => {
          if (lastSectionId === undefined) return;
          const totalRow = ws.getRow(rowNum++);
          totalRow.values = ['', `Итого: ${secName ?? 'Нераспределённые'}`, '', '', sectionSealSum, sectionSigSum, sectionDateSum, '', ''];
          totalRow.font = { bold: true, italic: true, color: { argb: 'FF64748B' } };
          totalRow.fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: 'FFF8FAFC' } };
          sectionSealSum = 0; sectionSigSum = 0; sectionDateSum = 0;
        };

        let idx = 0;
        for (const row of data.rows) {
          if (row.sectionId !== lastSectionId) {
            if (lastSectionId !== undefined) {
              const prevName = data.rows.find(r => r.sectionId === lastSectionId)?.sectionName ?? null;
              flushSectionTotal(prevName);
            }
            lastSectionId = row.sectionId;
          }
          sectionSealSum += row.sealCount;
          sectionSigSum += row.signatureCount;
          sectionDateSum += row.dateCount;

          const marksText = row.marks.length === 0
            ? ''
            : row.marks.map(m => m.page ? `${m.label} (стр. ${m.page})` : m.label).join('; ');

          const dataRow = ws.getRow(rowNum++);
          dataRow.values = [
            ++idx, row.filename, row.sectionName ?? 'Нераспределённые',
            row.isApproved ? 'Да' : 'Нет',
            row.sealCount, row.signatureCount, row.dateCount,
            marksText, ANALYSIS_LABELS[row.analysisStatus] ?? row.analysisStatus,
          ];
          if (row.isApproved) {
            dataRow.getCell('approved').font = { color: { argb: 'FF16A34A' }, bold: true };
          }
          if (row.marks.length > 0) {
            dataRow.getCell('marks').font = { color: { argb: 'FFDC2626' } };
          }
          dataRow.alignment = { vertical: 'top', wrapText: true };
        }

        const lastSectionName = data.rows.find(r => r.sectionId === lastSectionId)?.sectionName ?? null;
        flushSectionTotal(lastSectionName);

        const grandRow = ws.getRow(rowNum);
        grandRow.values = ['', 'ИТОГО по архиву', '', '',
          data.rows.reduce((s, r) => s + r.sealCount, 0),
          data.rows.reduce((s, r) => s + r.signatureCount, 0),
          data.rows.reduce((s, r) => s + r.dateCount, 0),
          '',
          `${data.rows.filter(r => r.isApproved).length} / ${data.rows.length} согласовано`,
        ];
        grandRow.font = { bold: true, size: 11 };
        grandRow.fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: 'FFE2E8F0' } };
        ws.views = [{ state: 'frozen', xSplit: 0, ySplit: 1 }];

        const dateStr = new Date().toISOString().split('T')[0];
        const safeName = data.project.name.replace(/[/\\:*?"<>|]/g, '_');
        res.setHeader('Content-Type', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
        res.setHeader('Content-Disposition', `attachment; filename*=UTF-8''${encodeURIComponent(`МБТ_${safeName}_${dateStr}.xlsx`)}`);
        const buffer = await wb.xlsx.writeBuffer();
        return res.send(buffer);
      }

      return res.json(data);
    } catch (error: any) {
      res.status(500).json({ message: error.message || 'Failed to generate report' });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
